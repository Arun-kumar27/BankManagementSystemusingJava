package com.bank.service;

public class adminException extends RuntimeException
{
	
	private String exceptionmsg;
	 public  adminException(String exceptionmsg)
	 {
		     super();
			this.exceptionmsg = exceptionmsg;
	 }

	
	public String getExceptionmsg() {
		return exceptionmsg;
	}
	public void setExceptionmsg(String exceptionmsg) {
		this.exceptionmsg = exceptionmsg;
	}
	@Override
	public String toString() {
		return "adminexception [exceptionmsg=" + exceptionmsg + "]";
	}
	 
	 

}
