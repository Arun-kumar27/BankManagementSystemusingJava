package com.bank.service;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class adminExceptionHandler 
{
	@ExceptionHandler(adminException.class)
   public String admindataexceptionhandler(adminException ade,Model model)
   {
	  String Exception= ade.getExceptionmsg();
	  model.addAttribute("Exception", Exception);
	  System.out.println("adminuserdetailsexception");
	  return"AdminRegistartion";
   }
	
	
	public String admindataExceptionHandler(adminException ade,Model model)
	{
		String exception=ade.getExceptionmsg();
		model.addAttribute("exception", exception);
		System.out.println("Adminloginpageexception");
		return "admintlogin";
		
	}
}
