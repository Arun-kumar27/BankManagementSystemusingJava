package com.bank.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bank.DAO.AdminUserDao;
import com.bank.DTO.AdminDEtailsDto;
import com.bank.entity.AdminDetails;
@Service
public class adminservidce 
{
	@Autowired
	private AdminUserDao adminUserDao; 
	public boolean adminregister(AdminDEtailsDto dto)
	{
		if(dto.getEmailid().contains("@gmail.com"))
		{
			
		}
		else
		{
			throw new adminException("invalid emailid");
		}
		
		if(dto.getPassword().length()==4)
		{
			
		}
		else
		{
			throw new adminException("invallid password");
		}
	
		AdminDetails adminDetails=new AdminDetails();
		adminDetails.setEmailid(dto.getEmailid());
		adminDetails.setPassword(dto.getPassword());
		adminDetails.setRole(dto.getRole());
		AdminDetails adminDetails1 =adminUserDao.insertAdminDEtails(adminDetails);
		if(adminDetails1.getId()>0)
		{
			return true;
		}
		else
		{
			throw new adminException("invallid password");
		}
	}
	
	public boolean validateloginrequest(int id)
	{
		if (adminUserDao.selectAdminDetailsByUsingId(id)) 
		{
			return true;
		} else 
		{
			
			throw new adminException("invallid Adminid");
		}
	}
	
}
