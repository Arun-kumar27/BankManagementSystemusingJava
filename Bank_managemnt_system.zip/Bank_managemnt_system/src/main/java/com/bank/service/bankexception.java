package com.bank.service;

public class bankexception  extends RuntimeException
{
	private String Exceptionmsg;

	public bankexception(String exceptionmsg) {
		super();
		Exceptionmsg = exceptionmsg;
	}

	public String getExceptionmsg() {
		return Exceptionmsg;
	}

	public void setExceptionmsg(String exceptionmsg) {
		Exceptionmsg = exceptionmsg;
	}

	@Override
	public String toString() {
		return "bankexception [Exceptionmsg=" + Exceptionmsg + "]";
	}

	


}
