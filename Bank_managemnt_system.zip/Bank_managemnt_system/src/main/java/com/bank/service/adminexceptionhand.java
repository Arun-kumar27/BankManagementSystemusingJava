package com.bank.service;

public class adminexceptionhand extends RuntimeException
{
	private String exceptionmsg;

	public adminexceptionhand(String exceptionmsg) {
		super();
		this.exceptionmsg = exceptionmsg;
	}

	public String getExceptionmsg() {
		return exceptionmsg;
	}

	public void setExceptionmsg(String exceptionmsg) {
		this.exceptionmsg = exceptionmsg;
	}

	@Override
	public String toString() {
		return "adminexceptionhand [exceptionmsg=" + exceptionmsg + "]";
	}
	

}
