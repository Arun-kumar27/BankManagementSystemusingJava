package com.bank.service;

import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.bank.DAO.BankUserDAO;
import com.bank.DTO.BankDetailsDto;
import com.bank.entity.BankUserDetails;

/*It is combination of @Component annotation
 * It is used to specify the class is called as service class which used to
 * data validation,user for writing business logic code
 * It also used to make the class as component class
 * it is used to create the bean of service class
 * it is having class access*/

@Service
public class bankservice  
{
	@Autowired
    private BankUserDAO bankUserDAO;
	public boolean UserRegistationData(BankDetailsDto dto ) 
	{
		
		String b=dto.getAadharnumber()+"";
		
		
		if( b.length()==12)
		{
			
		
		}
		else
		{
		  throw new bankDetailseException("invalid aadharnumber");
		}
	
	
		if(dto.getEmailid().contains("@gmail.com"))
		{
		
		}
		else
		{
			throw new bankDetailseException("invalid Emailid");
		}

		String c=dto.getMobilnumber()+"";
		if((dto.getMobilnumber()>=6000000000l && dto.getMobilnumber()<=9999999999l))
		{
			
	   }
		 else
		{
			throw new bankDetailseException("invalid mobilnumber");
		}
		BankUserDetails bankUserDetails=new BankUserDetails();
	       bankUserDetails.setName(dto.getName());
	       bankUserDetails.setEmailid(dto.getEmailid());
	       bankUserDetails.setAadharnumber(dto.getAadharnumber());
	       bankUserDetails.setAddress(dto.getAddress());
	       bankUserDetails.setAmount(dto.getAmount());
	       bankUserDetails.setGender(dto.getGender());
	       bankUserDetails.setMobilenumber(dto.getMobilnumber());
	       BankUserDetails userDetails=bankUserDAO.insertBankUserDetails(bankUserDetails);
	       System.out.println("Data base response"+userDetails);
	       if(userDetails.getUserid()>0)
	       {
	    	   return  true;
	       }
	       else
	       {
	    	   throw new  bankDetailseException("server 500  error");
	       }
		
       
	}
	public void emairegis(BankDetailsDto dto)
	{
		
       if(dto.getEmailid().equals("Arun@gmail.com"))
       {
	
       }
      else
       {
	  throw new bankDetailseException("invalid emailid");
	
      }
	}
       public boolean validateid(int userid)
       {
    	   
    	   if(bankUserDAO.selectuserdetailsByUsingId(userid))
    	   {
    		  return true; 
    	   }
    	   else
    	   {
    		   throw new bankDetailseException("invalid id");
    	   }
    	   
       }
       
       public List<BankUserDetails> getalltheuserdetails()
       {
    	   return bankUserDAO.selectalltheuserdetails();
    	   
       }
       
       public boolean deleteUserDetailsbyusingId(int userid)
       {
    	   return bankUserDAO.removeUserDataByUsingId(userid);
       }
       
       public BankUserDetails updateAlltheuserdatabyusingid(int userid)
       {
    	   return bankUserDAO.updateByID(userid);
       }
       
       public void updatebankuserdetailspage()
       {
//    	   return bankUserDAO.
       }
   
}


