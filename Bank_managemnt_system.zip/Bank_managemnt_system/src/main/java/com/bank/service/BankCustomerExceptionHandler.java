package com.bank.service;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;


/*@ControllerAdvice is the combination of @Component Annotation
 * It is used to specify the class is global exception handler or
 * the class is ready to handle the exception which are generated in the application
 * It is having class access
 * */
@ControllerAdvice
public class BankCustomerExceptionHandler 
{
/*@Exceptionhandler is used to specify which class exception is going to be handled
 * it is having method access*/	
//	@ResponseBody
	@ExceptionHandler(bankDetailseException.class)
	public String bankUserDataExceptionHandler(bankDetailseException bde,Model model)
	{
		String exceptionmsg=bde.getExceptionmsg();
		model.addAttribute("exceptionmsg", exceptionmsg);
		System.out.println("BankUserDataExceptionHandler");
		return "loginbankdetails";
//		return "validate";
		
	}
	
	@ExceptionHandler(bankexception.class)
	public String bankUserDataExceptionHandler1(bankDetailseException ade,Model model)
	{
		String Exceptionmsg1=ade.getExceptionmsg();
		model.addAttribute("Exceptionmsg1", Exceptionmsg1);
		System.out.println("bankuserAdminecxeptionhandlwer");
		return "logo";
	}

}





/*model is the interface which is used to send the data as a response on the web page
 * addAttribute() method is used to set the values in the model interface object
 * it is the non static ,two argument method ,over loaded method
 * Syntax:addAttribute(String name,object value) 
 * for the first argument provide the reference variable and second argument ovverride the object value
 * 
 *  which is to be stored
 *  
 *  To get the value from the model we need to make use of getAttribute method 
 *  it is non static method which is present in httpserveletRequest interface
 *  it is an argument method which can take string name as an argument
 *  it is a return type method which can return the object class
 *  
 *   To write the business logic java code in jsp page we can make use of scriptlet tag
 *   Syntax:<% write the business logic java code<%>
 *   to print the java code on jsp file we can make use the Expression tag
 *   Syntax:<%= provide the java code which can be printed on page%>*/
