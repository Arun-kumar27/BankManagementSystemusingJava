package com.bank.service;

public class bankDetailseException extends RuntimeException
{
	

	private  String exceptionmsg1;

	public bankDetailseException(String exceptionmsg1) {
		super();
		this.exceptionmsg1 = exceptionmsg1;
	}

	public String getExceptionmsg() {
		return exceptionmsg1;
	}

	public void setExceptionmsg(String exceptionmsg1) {
		this.exceptionmsg1 = exceptionmsg1;
	}
	
	@Override
	public String toString() {
		return "bankDetailseException [exceptionmsg1=" + exceptionmsg1 + "]";
	}
	

}
