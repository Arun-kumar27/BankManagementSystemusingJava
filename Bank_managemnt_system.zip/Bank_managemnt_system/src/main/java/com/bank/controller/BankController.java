package com.bank.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bank.DTO.BankDetailsDto;
import com.bank.entity.BankUserDetails;
import com.bank.service.bankservice;

@Controller
public class BankController 
{
	@Autowired
	private bankservice service;
	@RequestMapping("/register")
	public String regispage()
	{
		System.out.println("register method is called");
		return "logo";
	}
//	@ResponseBody
	@RequestMapping("/validate")
	public String userregister(BankDetailsDto dto)
	{

//	if(!service.validformobile(dto.getMobilnumber()))
//	{
//		return "invalid mobilrnumber";
//	}
//	else if(!service.datavalidationforaddar(dto.getAadharnumber()))
//	{
//		return "invalid addar";
//	}
//	else if(!service.validationforemailid(dto.getEmailid()))
//	{
//		return "invalid eamid";
//	}
//	else
//	{
//		return"register successfull";
//	}
//		
//	}
	if(service.UserRegistationData(dto))
	{
		return "logo";
	}
	return null;
//	return"<center><h1>Registartion succesfully completed</h1></center>"; 
		
	}
	
	@ResponseBody
	@RequestMapping("/loginnnnn")
	public String loginpage(BankDetailsDto dto,String emailid)
	{
		service.emairegis(dto);
		System.out.println("updatemethod is calling");
		return"<center><h1>login succesfully completed</h1></center>";
	}
	
	
	@ResponseBody
	@RequestMapping("/userloginrequest")
	public String bankloginrequest(@RequestParam("userid") int adminid)
	{
		if(service.validateid(adminid))
		{
			return "<center><h1>login successgull</h1></center>";
	    }
	   else
	    {
		return "<center></h1>invalid id</h1></center>";
	    }
		
	}
	
	@RequestMapping("/getAllUserDetails")
	public String getBankAllUserDetailsRequest( Model model)
	{
		List<BankUserDetails> bankUserDetails =service.getalltheuserdetails();
		System.out.println(bankUserDetails);
		model.addAttribute("bankuserdetails", bankUserDetails);
		return "AllBankUserDEtails";
	}
	@RequestMapping("/deleteUsingId")
	public String deleteUserRequest(@RequestParam("userid") int userid)
	{
		System.out.println(userid);
		boolean usingid=service.deleteUserDetailsbyusingId(userid);
		if(usingid)
		{
			return"redirect:/arun/getAllUserDetails";
		}
		return null;
	}
	
	@RequestMapping("/updatebyid")
	public String upadatedatabyusingid(@RequestParam("userid") int userid,Model model)
	{
		
		 BankUserDetails bankUserDetails=service.updateAlltheuserdatabyusingid(userid);
		 System.out.println(bankUserDetails);
	
		 model.addAttribute("bankdetails", bankUserDetails);
		 return "updatedetails";
	}
	
	public void updateuserdetails()
	{
		
	}
}
