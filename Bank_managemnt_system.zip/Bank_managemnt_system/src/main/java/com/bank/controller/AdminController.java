package com.bank.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bank.DTO.AdminDEtailsDto;
import com.bank.service.adminservidce;

@Controller
public class AdminController 
{
	@Autowired
	adminservidce adminservidce;
	@RequestMapping("/adminregpage")
	public String adminRegistrationPage()
	{
		return"AdminRegistartion";
	}
	
//	@ResponseBody
	@RequestMapping("/adminregistration")
	public String AdminRegistartionrequest(AdminDEtailsDto adminDEtailsDto)
	{
		if(adminservidce.adminregister(adminDEtailsDto))
		{
			return"admintlogin";
		}
		return null;
		
		
	}
	
	@RequestMapping("/adminloginpage")
	public String adminloginpage()
	{
		return "admintlogin";
	}
	
//	@ResponseBody
	@RequestMapping("/adminloginrequest")
	public String adminloginrequest(@RequestParam("id") int adminid)
    {
		if(adminservidce.validateloginrequest(adminid))
		{
//			return "<center><h1>login successgull</h1></center>";
			return "adminoperation";
		}
		else
		{
//			return "<center></h1>invalid</h1></center>";
			return null;
		}
		
	}
	

}
