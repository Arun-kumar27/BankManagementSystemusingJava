package com.bank.DTO;

import org.springframework.stereotype.Component;

@Component
public class BankDetailsDto 
{
	private String name;
	private String emailid;
	private long aadharnumber;
	private long mobilnumber;
	private String gender;
	private String address;
	private double amount;
	
	public BankDetailsDto()
	{
		
	}

	public BankDetailsDto(String name, String emailid, long aadharnumber, long mobilnumber, String gender,
			String address, double amount) {
		super();
		this.name = name;
		this.emailid = emailid;
		this.aadharnumber = aadharnumber;
		this.mobilnumber = mobilnumber;
		this.gender = gender;
		this.address = address;
		this.amount = amount;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmailid() {
		return emailid;
	}

	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}

	public long getAadharnumber() {
		return aadharnumber;
	}

	public void setAadharnumber(long aadharnumber) {
		this.aadharnumber = aadharnumber;
	}

	public long getMobilnumber() {
		return mobilnumber;
	}

	public void setMobilnumber(long mobilnumber) {
		this.mobilnumber = mobilnumber;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "BankDetailsDto [name=" + name + ", emailid=" + emailid + ", aadharnumber=" + aadharnumber
				+ ", mobilnumber=" + mobilnumber + ", gender=" + gender + ", address=" + address + ", amount=" + amount
				+ "]";
	}
	

}
