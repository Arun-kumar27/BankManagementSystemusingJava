package com.bank.config;

import javax.persistence.EntityManagerFactory;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalEntityManagerFactoryBean;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

@Configuration
@ComponentScan(basePackages = "com.bank")
@EnableJpaRepositories("com.bank.repository")
public class BankConfig {
	@Bean
	public InternalResourceViewResolver viewresioverBean() {
		InternalResourceViewResolver viewresolver = new InternalResourceViewResolver();
		viewresolver.setPrefix("/");
		viewresolver.setSuffix(".jsp");
		return viewresolver;
	}

	@Bean(name="entityManagerFactory")
	public LocalEntityManagerFactoryBean LocalEntityManagerFactoryBean() {
		LocalEntityManagerFactoryBean localEntityManagerFactoryBean = new LocalEntityManagerFactoryBean();
		localEntityManagerFactoryBean.setPersistenceUnitName("Bank_managemnt_system");
		return localEntityManagerFactoryBean;
	}

	@Bean(name="transactionManager")
	public JpaTransactionManager jpaTrasactionManager(EntityManagerFactory emf) {
		JpaTransactionManager jpaTransactionManager = new JpaTransactionManager();
		jpaTransactionManager.setEntityManagerFactory(emf);
		return jpaTransactionManager;

	}

}
