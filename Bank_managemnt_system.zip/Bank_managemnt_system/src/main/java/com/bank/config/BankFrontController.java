package com.bank.config;

import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;

public class BankFrontController extends AbstractAnnotationConfigDispatcherServletInitializer {

	@Override
	protected Class<?>[] getRootConfigClasses() {
		
		return null;
	}

	@Override
	protected Class<?>[] getServletConfigClasses() {
		Class[] springconfig= {BankConfig.class};
		return springconfig;
	}

	@Override
	protected String[] getServletMappings() {
		String [] mappings= {"/arun/*"};
		return mappings;
	}

}
