package com.bank.DAO;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bank.entity.AdminDetails;
import com.bank.repository.BankUserRepository;
import com.bank.repository.adminrepository;
@Repository
public class AdminUserDao 
{
	@Autowired
	private adminrepository adminrepository;
	public AdminDetails insertAdminDEtails(AdminDetails adminDetails )
	{
		return adminrepository.save(adminDetails);
	}
	public boolean	selectAdminDetailsByUsingId(int id)
	{
		Optional<AdminDetails>admindetails=adminrepository.findById( id);
		return admindetails.isPresent();
//		return adminrepository.findById(id).isPresent();
	}
	

}
