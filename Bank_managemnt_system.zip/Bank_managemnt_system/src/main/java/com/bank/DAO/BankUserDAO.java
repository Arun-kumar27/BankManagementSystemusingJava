package com.bank.DAO;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bank.entity.BankUserDetails;
import com.bank.repository.BankUserRepository;
import com.bank.repository.adminrepository;

@Repository
public class BankUserDAO {
	@Autowired
	private BankUserRepository bankUserRepository;

	public BankUserDetails insertBankUserDetails(BankUserDetails bankUserDetails) {
		// insertion
		return bankUserRepository.save(bankUserDetails);
	}

	public boolean selectuserdetailsByUsingId(int id) {
//	  Optional<BankUserDetails> bankuserdetails =bankUserRepository.findById(id);
		return bankUserRepository.findById(id).isPresent();
	}

	public List<BankUserDetails> selectalltheuserdetails() {
		List<BankUserDetails> list = bankUserRepository.findAll();
		return list;
	}
	
	public boolean removeUserDataByUsingId(int userid)
	{
		bankUserRepository.deleteById( userid);
		return true;
	}
	
	public BankUserDetails updateByID(int userid)
	{
//		Optional<BankUserDetails>userdetails=bankUserRepository.findById(userid);
		return bankUserRepository.findById(userid).get();
	}
	
	public void updateTheDetailsOfTheUser()
	{
//		return bankUserRepository.
	}

}
