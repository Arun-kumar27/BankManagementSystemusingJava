package com.bank.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="bank_user_details")
public class BankUserDetails
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="user_id")
	private int userid;
	@Column(name="user_name")
	private String name;
	@Column(name="user_emailid")
	private String emailid;
	@Column(name="user_mobilenumber")
	private long mobilenumber;
	@Column(name="user_aadharnumber")
	private long aadharnumber;
	@Column(name="user_gender")
	private String gender;
	@Column(name="user_address")
	private String address;
	@Column(name="user_amount")
	private double amount;
	@Column(name="user_accountnumber")
	private int accountnumber;
	@Column(name="user_pinnumber")
	private int pinnumber;
	@Column(name="user_ifsccode")
	private String ifscode;
	@Column(name="user_branch")
	private String branch;
	
	public BankUserDetails()
	{
		
	}
	public BankUserDetails(int userid, String name, String emailid, long mobilenumber, long aadharnumber, String gender,
			String address, double amount, int accountnumber, int pinnumber, String ifscode, String branch) {
		super();
		this.userid = userid;
		this.name = name;
		this.emailid = emailid;
		this.mobilenumber = mobilenumber;
		this.aadharnumber = aadharnumber;
		this.gender = gender;
		this.address = address;
		this.amount = amount;
		this.accountnumber = accountnumber;
		this.pinnumber = pinnumber;
		this.ifscode = ifscode;
		this.branch = branch;
	}
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	public long getMobilenumber() {
		return mobilenumber;
	}
	public void setMobilenumber(long mobilenumber) {
		this.mobilenumber = mobilenumber;
	}
	public long getAadharnumber() {
		return aadharnumber;
	}
	public void setAadharnumber(long aadharnumber) {
		this.aadharnumber = aadharnumber;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public int getAccountnumber() {
		return accountnumber;
	}
	public void setAccountnumber(int accountnumber) {
		this.accountnumber = accountnumber;
	}
	public int getPinnumber() {
		return pinnumber;
	}
	public void setPinnumber(int pinnumber) {
		this.pinnumber = pinnumber;
	}
	public String getIfscode() {
		return ifscode;
	}
	public void setIfscode(String ifscode) {
		this.ifscode = ifscode;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	@Override
	public String toString() {
		return "BankUserDetails [userid=" + userid + ", name=" + name + ", emailid=" + emailid + ", mobilenumber="
				+ mobilenumber + ", aadharnumber=" + aadharnumber + ", gender=" + gender + ", address=" + address
				+ ", amount=" + amount + ", accountnumber=" + accountnumber + ", pinnumber=" + pinnumber + ", ifscode="
				+ ifscode + ", branch=" + branch + "]";
	}
	
	

}
